X_POS = 1
Y_POS = 2
N_TOKENS = 0

BOARD_SIZE = 8

ACTION = 0
FROM = 1
TO = 2

DEBUG = False